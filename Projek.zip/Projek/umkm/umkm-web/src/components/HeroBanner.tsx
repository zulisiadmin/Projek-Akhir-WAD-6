import React from 'react'

const HeroBanner = () => {
  return (
    <div>
      
    </div>
  )
}

export default HeroBanner
